package com.imoo.jdbc.service;

import com.imoo.jdbc.bean.Message;
import com.imoo.jdbc.dao.MessageDAO;

import java.util.Date;
import java.util.List;

/**
 * 消息Service
 */
public class MessageService {

    private MessageDAO messageDAO;

    public MessageService() {
        messageDAO = new MessageDAO();
    }

    public List<Message> getMessagesByUser(int page, int pageSize, Long userId) {
        return messageDAO.getMessagesByUser(page, pageSize, userId);
    }
    
    /**
     * 查询一个
     */
    public Message findOne(Integer id) {
    	return messageDAO.findOne(id);
    }

    /**
     * 新增留言
     * @param message
     * @return
     */
    public boolean addMessage(Message message) {
        message.setCreateTime(new Date());
        return messageDAO.save(message);
    }

    /**
     * 分页查询全部留言
     * @param page 当前页码
     * @param pageSize 每页记录数
     * @return
     */
    public List<Message> getMessages(int page, int pageSize) {
        return messageDAO.getMessages(page, pageSize);
    }

    /**
     * 计算所有留言数量
     * @return
     */
    public int countMessages() {
        return messageDAO.countMessages();
    }

	public void updateMessage(long id, String title, String content, long id2) {
		messageDAO.updateMessage(id,title,content,id2);
		
	}

	public Message getMessages(int id) {
		Message ms=new Message();
		ms=messageDAO.getMessages(id);
		return ms;
	}

	public void deleteMessage(int id, long userid) {
		messageDAO.deleteMessage(id,userid);
		
	}

}
