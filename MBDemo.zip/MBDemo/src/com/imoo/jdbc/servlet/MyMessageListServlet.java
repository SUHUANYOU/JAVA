package com.imoo.jdbc.servlet;

import com.imoo.jdbc.bean.Message;
import com.imoo.jdbc.bean.User;
import com.imoo.jdbc.service.MessageService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet("/MyMessageListServlet")
public class MyMessageListServlet extends HttpServlet {

    private MessageService messageService;

    @Override
    public void init() throws ServletException {
        super.init();
        messageService = new MessageService();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pageStr = req.getParameter("page");
        Long userId = ((User) req.getSession().getAttribute("user")).getId();
        int page = 1;   //页码默认值是1
        if (null != pageStr && !"".equals(pageStr)) {
            try {
                page = Integer.parseInt(pageStr);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        List<Message> messages = messageService.getMessagesByUser(page, 5, userId);   //分页查询全部留言
        int count = messageService.countMessages();
        int last = (count % 5 == 0) ? (count / 5) : ((count / 5) + 1);    //计算最后一页的页码
        req.setAttribute("last", last);
        req.setAttribute("messages", messages);
        req.setAttribute("page", page);
        req.getRequestDispatcher("/WEB-INF/views/biz/my_message_list.jsp").forward(req, resp);
    }

    @Override
    public void destroy() {
        super.destroy();
        messageService = null;
    }
}
