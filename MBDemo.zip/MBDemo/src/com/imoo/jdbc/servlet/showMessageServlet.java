package com.imoo.jdbc.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.imoo.jdbc.bean.Message;
import com.imoo.jdbc.dao.MessageDAO;
import com.imoo.jdbc.service.MessageService;

/**
 * Servlet implementation class MessageExServlet
 */
@WebServlet("/showMessageServlet")
public class showMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		System.out.println(id);
		MessageService msi=new MessageService();
		Message mess=msi.getMessages(id);
		System.out.println(mess);
		request.setAttribute("message",mess);
		request.getRequestDispatcher("/WEB-INF/views/biz/edit_message.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	
	
	


}
