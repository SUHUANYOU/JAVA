package com.imoo.jdbc.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.imoo.jdbc.bean.User;
import com.imoo.jdbc.service.MessageService;

/**
 * Servlet implementation class deleteMessageServlet
 */
@WebServlet("/deleteMessageServlet")
public class deleteMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接收数据
		int id=Integer.parseInt(request.getParameter("id"));
		User user=new User();
		user=(User)request.getSession().getAttribute("user");
		MessageService msi=new MessageService();
		msi.deleteMessage(id,user.getId());
		
		response.sendRedirect(request.getContextPath()+"/MyMessageListServlet");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
