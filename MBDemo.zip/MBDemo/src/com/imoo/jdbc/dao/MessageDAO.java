package com.imoo.jdbc.dao;

import com.imoo.jdbc.bean.Message;
import com.imoo.jdbc.common.ConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 消息DAO
 */
public class MessageDAO {

    public List<Message> getMessagesByUser(int page, int pageSize, Long userId) {
        Connection conn = ConnectionUtil.getConnection();
        String sql = "select * from message where user_id = ? order by create_time desc limit ?, ?";  //limit m, n:意思是从第m条开始取出总共n条记录
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Message> messages = new ArrayList<>();
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setLong(1, userId);
            stmt.setInt(2, (page - 1) * pageSize);
            stmt.setInt(3, pageSize);
            rs = stmt.executeQuery();
            while (rs.next()) {
                messages.add(new Message(rs.getLong("id"),
                        rs.getLong("user_id"),
                        rs.getString("username"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getTimestamp("create_time")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionUtil.release(rs, stmt, conn);
        }
        return messages;
    }

    /**
     * 保存留言信息
     * @param message
     * @return
     */
    public boolean save(Message message) {
        Connection conn = ConnectionUtil.getConnection();
        String sql = "insert into message(user_id, username, title, content, create_time) values(?, ?, ?, ?, ?)";
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setLong(1, message.getUserId());
            stmt.setString(2, message.getUsername());
            stmt.setString(3, message.getTitle());
            stmt.setString(4, message.getContent());
            stmt.setTimestamp(5, new Timestamp(message.getCreateTime().getTime()));
            stmt.execute();
        } catch (Exception e) {
            System.out.println("保存留言信息失败。");
            e.printStackTrace();
            return false;
        } finally {
            ConnectionUtil.release(null, stmt, conn);
        }
        return true;
    }

    /**
     * 分页查询全部留言
     *
     * @param page     当前页码
     * @param pageSize 每页记录数
     * @return
     */
    public List<Message> getMessages(int page, int pageSize) {
        Connection conn = ConnectionUtil.getConnection();
        String sql = "select * from message order by create_time desc limit ?, ?";  //limit m, n:意思是从第m条开始取出总共n条记录
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Message> messages = new ArrayList<>();
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, (page - 1) * pageSize);
            stmt.setInt(2, pageSize);
            rs = stmt.executeQuery();
            while (rs.next()) {
                messages.add(new Message(rs.getLong("id"),
                        rs.getLong("user_id"),
                        rs.getString("username"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getTimestamp("create_time")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionUtil.release(rs, stmt, conn);
        }
        return messages;
    }

    /**
     * 计算所有留言数量
     *
     * @return
     */
    public int countMessages() {
        Connection conn = ConnectionUtil.getConnection();
        String sql = "select count(*) total from message";
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionUtil.release(rs, stmt, conn);
        }
        return 0;
    }

	public Message findOne(Integer id) {
		Connection conn=ConnectionUtil.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			
			String sql="select * from message m,user u where m.user_id=u.id and m.id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Message message=new Message();
				message.setId(rs.getLong("id"));
				message.setUserId(rs.getLong("user_id"));
				message.setUsername(rs.getString("username"));
				message.setTitle(rs.getString("title"));
				message.setContent(rs.getString("content"));
				message.setCreateTime(rs.getTimestamp("create_time"));
				return message;
			
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConnectionUtil.release(rs, pstmt, conn);
		}
		return null;
	}

	public void updateMessage(long id, String title, String content, long id2) {
		Connection conn=ConnectionUtil.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			String sql="update message set title=?, content=? ,create_time=? where message.id=? and user_id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
			pstmt.setLong(4, id);
			pstmt.setLong(5, id2);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConnectionUtil.release(rs, pstmt, conn);
		}
		
	}


	public Message getMessages(int id) {
		System.out.println(id);
		Connection conn=ConnectionUtil.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Message ms=new Message();
		try {
			String sql="select * from message as m,user as u where m.user_id=u.id and m.id=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				
				ms.setId(rs.getLong("id"));
				
				ms.setUserId(rs.getLong("user_id"));
				ms.setUsername(rs.getString("username"));
				ms.setTitle(rs.getString("title"));
				ms.setContent(rs.getString("content"));
				ms.setCreateTime(rs.getTimestamp("create_time"));
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConnectionUtil.release(rs, pstmt, conn);
		}
		return ms;
	}

	public void deleteMessage(int id, long userid) {
		Connection conn=ConnectionUtil.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			String sql="delete from message where id=? and user_id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.setLong(2, userid);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConnectionUtil.release(rs, pstmt, conn);
		}
				
	}

}
