package com.book.utils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class UploadUtils {
	
	public static String getUuidFileName(String fileName) {
		
		int idx=fileName.lastIndexOf(".");
		String exName=fileName.substring(idx);
		
		String uuidFileName=UUID.randomUUID().toString().replace("-","")+exName;
		return uuidFileName;
		
	}
	
	public static Map<String,String> operateFileUploadRequest(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map<String,String> objectMap=new HashMap<String,String>();
		
		DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory();

		ServletFileUpload fileUpload = new ServletFileUpload(diskFileItemFactory);
		
		try {
			List<FileItem> list = fileUpload.parseRequest(request);
			
			for (FileItem fileItem : list) {
				
				if (fileItem.isFormField()) {
					String name = fileItem.getFieldName();
					
					String value = fileItem.getString("UTF-8");
					objectMap.put(name,value);
				} else {
					
					
					String fileName = fileItem.getName();
					
					String uuidFileName=UploadUtils.getUuidFileName(fileName);
					
					InputStream is = fileItem.getInputStream();
					
					System.out.println("request.getContextPath():"+request.getContextPath());
					objectMap.put("path",request.getContextPath()+"/upload/"+uuidFileName);
					
					String url=request.getServletContext().getRealPath("/upload")+"\\"+uuidFileName;
					System.out.println("url:"+request.getServletContext().getRealPath("/upload"+"\\"+uuidFileName));
					OutputStream os = new FileOutputStream(url);
					int len = 0;
					byte[] b = new byte[1024];
					while ((len = is.read(b)) != -1) {
						os.write(b, 0, len);
					}
					is.close();
					os.close();
				}
			}
		} catch (FileUploadException e) {
			System.out.println("catch....." + e);
		}
		
		return objectMap;
	}
	
	public static void main(String args[]) {
		System.out.println(getUuidFileName("a.jpg"));
	}

}
